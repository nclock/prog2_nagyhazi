var searchData=
[
  ['dokumentáció_0',['Dokumentáció',['../index.html',1,'']]]
];
