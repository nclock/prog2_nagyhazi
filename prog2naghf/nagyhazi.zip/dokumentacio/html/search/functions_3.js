var searchData=
[
  ['lift_0',['Lift',['../class_lift.html#abee81e552021042c3b3c6a6335314648',1,'Lift::Lift()'],['../class_lift.html#a03ede85dd1860a1b7fc798dfb3e68e87',1,'Lift::Lift(const Lift &amp;)=default']]]
];
