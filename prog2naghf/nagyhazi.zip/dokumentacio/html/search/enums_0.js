var searchData=
[
  ['direction_0',['Direction',['../lift_8h.html#a224b9163917ac32fc95a60d8c1eec3aa',1,'lift.h']]]
];
