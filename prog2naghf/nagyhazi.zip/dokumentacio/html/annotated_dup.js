var annotated_dup =
[
    [ "Lift", "class_lift.html", "class_lift" ],
    [ "Toronyhaz", "class_toronyhaz.html", "class_toronyhaz" ]
];